package tancky;

public enum Direction {
	
	U , RU , R , RD , D , LD , L , LU, STOP 

}
